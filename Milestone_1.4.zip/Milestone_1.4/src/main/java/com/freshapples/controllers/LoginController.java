package com.freshapples.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.freshapples.model.LoginModel;
import com.freshapples.model.UserModel;
import com.freshapples.services.UsersBusinessServiceInterface;

import jakarta.validation.Valid;


/*
 * Login Controller directs the mapping for GET requests
 * sent to the root URI and redirect to /dologin upon successful
 * submission. Purpose is to log the user from the UserModel into 
 * the application through validation in the database.
 * 
 * */
@Controller
@RequestMapping("/")
public class LoginController {

	private LoginModel loginModel;
	private UsersBusinessServiceInterface service;
	
	// Adds login mappings to all URLs.
	public LoginController(LoginModel loginModel, UsersBusinessServiceInterface service) {
		super();
		this.service = service;
		this.loginModel = loginModel;
	}
	
	@GetMapping("/")
	public String display(Model model) {
		model.addAttribute("title", "Login Form");
		model.addAttribute("loginModel", loginModel);
		
		return "login";
	}
	
	// For table functionality in HTML page.
	@PostMapping("/doLogin")
	public String doLogin(@Valid LoginModel loginModel, BindingResult bindingResult, Model model) {
		
		// Data validation error checking.
		if(bindingResult.hasErrors()) {
			model.addAttribute("title", "Login Form");
			return "login"; // Success.
		}

		System.out.println(String.format("Form with Username of %s and Password of %s", loginModel.getUsername(), loginModel.getPassword()));
		
		boolean success = false;
		
		//Searches MySQL database for user 
		for(UserModel i : service.getUsers()) {
			if(validate(i, loginModel))
				success = true;
		}
		
		//If user is found then display home page, if not then return to login page
		if(success) {
			return "home";
		} else {
			System.out.println("Incorrect");
			model.addAttribute("title", "Login Form");
			return "login"; // Success.
		}
		
	}
	//Validates that user entered matches user in database
	private boolean validate(UserModel i, LoginModel loginModel) {
		
		if(i.getUsername().equals(loginModel.getUsername()) && i.getPassword().equals(loginModel.getPassword()))
			return true; // Success.

		return false;
	}
}